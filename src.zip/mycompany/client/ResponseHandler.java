package mycompany.client;

import java.util.Scanner;

public interface ResponseHandler {

    public void handle(Scanner scanner);
}
